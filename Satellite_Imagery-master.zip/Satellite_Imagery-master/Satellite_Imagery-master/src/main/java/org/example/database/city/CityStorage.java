package org.example.database.city;

import org.example.database.LocationStorage;
import org.example.domain.location.City;

public interface CityStorage extends LocationStorage<City> {}
