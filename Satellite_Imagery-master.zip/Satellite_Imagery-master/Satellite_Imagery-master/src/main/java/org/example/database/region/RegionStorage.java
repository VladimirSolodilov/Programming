package org.example.database.region;

import org.example.database.LocationStorage;
import org.example.domain.location.Region;

public interface RegionStorage extends LocationStorage<Region> {}
