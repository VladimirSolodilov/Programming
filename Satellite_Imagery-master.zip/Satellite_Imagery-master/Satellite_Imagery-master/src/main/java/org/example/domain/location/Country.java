package org.example.domain.location;

public class Country extends Location {
}
