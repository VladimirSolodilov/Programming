import {setUpLinks} from "/js/modules/jumper/Linker.js";

setUpLinks(document.getElementsByClassName("ajaxLink"));
